<div class="modal fade" id="<?=$modal_id?>" tabindex="-1" role="dialog">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title" id="defaultModalLabel"><?=$title?></h4>
			</div>
			<div class="modal-body">
				<?=$message?>
			</div>
			<div class="modal-footer">
				
				<button type="button" class="btn btn-link waves-effect" id="confirm-btn-generate-folder-project-charter">Yes</button>
				<button type="button" class="btn btn-link waves-effect" data-dismiss="modal">No</button>
			</div>
		</div>
	</div>
</div>
<script>
		// var color = $("#btn-approve-project-charter").data("color");
		// $("#modal-check-approve-project-charter .modal-content")
		// 	.removeAttr("class")
		// 	.addClass("modal-content modal-col-" + color);
					
		// $("#modal-check-approve-project-charter").modal("show")

		// alert("asdasd")
		// console.log("kami disini")
</script>
