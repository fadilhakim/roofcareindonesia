<div id="class" class="">
  <div class="content-wrap">
    <div class="container">

      <div class="row">
        <div class="col-lg-12">
          <h2>Oops! Sepertinya halaman ini belum tersedia, <br> Coba kembali ke halaman Awal.</h2>
          <a class="btn btn-primary" href="<?= base_url();?>">Kembali ke Home</a>
        </div>

      </div>
    </div>
  </div>
</div>
