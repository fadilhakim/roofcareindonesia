<div class="section banner-page" data-background="<?= base_url() ?>public/images/dummy/dummy-img-1920x300.jpg">
		<div class="content-wrap pos-relative">
			<div class="container">
				<div class="col-12 col-md-12">
					<div class="d-flex bd-highlight mb-2">
						<div class="title-page">Residentials</div>
					</div>
					<nav aria-label="breadcrumb">
					  <ol class="breadcrumb ">
					    <li class="breadcrumb-item"><a href="index.html">Projects</a></li>
					    <li class="breadcrumb-item active" aria-current="page">Residentials</li>
					  </ol>
					</nav>
				</div>
			</div>
			
		</div>
	</div>


    <div class="section">
		<div class="content-wrap">
			<div class="container">
				<div class="row">
					<!-- Item 1 -->
					<div class="col-sm-12 col-md-12 col-lg-4">
						<div class="feature-box-7 shadow">
							<div class="media-box">
								<a href="services-detail.html"><img src="<?= base_url() ?>public/images/dummy/dummy-img-600x500.jpg" alt="" class="img-fluid"></a>
							</div>
							<div class="body">
								<div class="info-box">
									<div class="text">
										<div class="title">Residentials-1</div>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. </p>
										<a href="services-detail.html" title="Get Detail">Get Detail</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Item 2 -->
					<div class="col-sm-12 col-md-12 col-lg-4">
						<div class="feature-box-7 shadow">
							<div class="media-box">
								<a href="services-detail.html"><img src="<?= base_url() ?>public/images/dummy/dummy-img-600x500.jpg" alt="" class="img-fluid"></a>
							</div>
							<div class="body">
								<div class="info-box">
									<div class="text">
										<div class="title">Residentials-2</div>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. </p>
										<a href="services-detail.html" title="Get Detail">Get Detail</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Item 3 -->
					<div class="col-sm-12 col-md-12 col-lg-4">
						<div class="feature-box-7 shadow">
							<div class="media-box">
								<a href="services-detail.html"><img src="<?= base_url() ?>public/images/dummy/dummy-img-600x500.jpg" alt="" class="img-fluid"></a>
							</div>
							<div class="body">
								<div class="info-box">
									<div class="text">
										<div class="title">Residentials-3</div>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. </p>
										<a href="services-detail.html" title="Get Detail">Get Detail</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Item 4 -->
					<div class="col-sm-12 col-md-12 col-lg-4">
						<div class="feature-box-7 shadow">
							<div class="media-box">
								<a href="services-detail.html"><img src="<?= base_url() ?>public/images/dummy/dummy-img-600x500.jpg" alt="" class="img-fluid"></a>
							</div>
							<div class="body">
								<div class="info-box">
									<div class="text">
										<div class="title">Residentials-4</div>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. </p>
										<a href="services-detail.html" title="Get Detail">Get Detail</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Item 5 -->
					<div class="col-sm-12 col-md-12 col-lg-4">
						<div class="feature-box-7 shadow">
							<div class="media-box">
								<a href="services-detail.html"><img src="<?= base_url() ?>public/images/dummy/dummy-img-600x500.jpg" alt="" class="img-fluid"></a>
							</div>
							<div class="body">
								<div class="info-box">
									<div class="text">
										<div class="title">Residentials-5</div>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. </p>
										<a href="services-detail.html" title="Get Detail">Get Detail</a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<!-- Item 6 -->
					<div class="col-sm-12 col-md-12 col-lg-4">
						<div class="feature-box-7 shadow">
							<div class="media-box">
								<a href="services-detail.html"><img src="<?= base_url() ?>public/images/dummy/dummy-img-600x500.jpg" alt="" class="img-fluid"></a>
							</div>
							<div class="body">
								<div class="info-box">
									<div class="text">
										<div class="title">Residentials-6</div>
										<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry orem Ipsum has been. </p>
										<a href="services-detail.html" title="Get Detail">Get Detail</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div> 