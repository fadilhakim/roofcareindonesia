<?php $header_web; ?>
<?php $content_web; ?>
<?php $footer_web; ?>
