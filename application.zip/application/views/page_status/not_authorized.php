
<section class="content">
	<div class="container-fluid">
		<div class="row clearfix">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="card">
					<div class="header">
						<h2>
							401 Unauthorized
						</h2>
					</div>
					<div class="body">
						<div>
							<p> You are not authorized access this page </p> 
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

